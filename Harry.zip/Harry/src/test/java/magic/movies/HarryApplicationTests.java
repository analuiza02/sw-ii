package magic.movies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarryApplicationTests {

	@Test
	void contextLoads() {
	}

}
